# gridtext 0.1.1

- `richtext_grob()` and `textbox_grob()` now gracefully handle empty strings
  and NAs.

# gridtext 0.1.0

First public release. Provides the two grobs `richtext_grob()` and `textbox_grob()` for formatted text rendering without and with word wrapping, respectively.
